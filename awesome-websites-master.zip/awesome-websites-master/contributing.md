## Contribution Guidelines

I am well aware of the fact that this list is like a drop in the ocean of the Internet. There are so many cool websites out there which I haven't came across yet so haven't added in this list. 

So, if you know any such websites and it is not included in this list then you are always welcome to add more awesome/funny/informational/productive/educational websites in this list by creating a PR. If you find something wrong or any website in the list is down then please notify me by creating an issue.

I hope y'all enjoy contributing to my collection. :blush:
